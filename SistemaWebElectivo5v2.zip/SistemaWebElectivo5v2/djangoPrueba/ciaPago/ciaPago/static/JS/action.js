$(window).on('load', function() {
	/*$('#inicioSesion').removeClass('fade');*/
	$('#inicioSesion').modal('show');
	/*$('#inicioSesion').addClass('fade');*/
	document.getElementById('errorM').style.display = 'inherit';
});